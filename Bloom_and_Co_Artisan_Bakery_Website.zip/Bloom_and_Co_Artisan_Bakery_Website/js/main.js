
/* =========================================
   BLOOM & CO. ARTISAN BAKERY
   Main JavaScript
========================================= */

document.addEventListener("DOMContentLoaded", function () {

    // UPDATE THIS EMAIL BEFORE PUBLISHING
    const bakeryEmail = "hello@example.com";

    // =====================================
    // CURRENT YEAR
    // =====================================

    document.querySelectorAll(".year").forEach(function (element) {
        element.textContent = new Date().getFullYear();
    });

    // =====================================
    // MOBILE NAVIGATION
    // =====================================

    const menuToggle = document.querySelector(".menu-toggle");
    const mainNav = document.querySelector(".main-nav");

    if (menuToggle && mainNav) {

        menuToggle.addEventListener("click", function () {

            const isOpen = mainNav.classList.toggle("open");

            menuToggle.setAttribute("aria-expanded", String(isOpen));
            menuToggle.setAttribute(
                "aria-label",
                isOpen ? "Close navigation" : "Open navigation"
            );

            menuToggle.textContent = isOpen ? "×" : "☰";
        });

        mainNav.querySelectorAll("a").forEach(function (link) {

            link.addEventListener("click", function () {
                mainNav.classList.remove("open");
                menuToggle.setAttribute("aria-expanded", "false");
                menuToggle.setAttribute("aria-label", "Open navigation");
                menuToggle.textContent = "☰";
            });

        });

    }

    // =====================================
    // MENU SEARCH AND CATEGORY FILTER
    // =====================================

    const menuSearch = document.getElementById("menuSearch");
    const menuCards = document.querySelectorAll(".menu-card");
    const filterButtons = document.querySelectorAll(".filter-btn");
    const menuCount = document.getElementById("menuCount");
    const noMenuResults = document.getElementById("noMenuResults");

    let selectedCategory = "all";

    function filterMenu() {

        if (!menuCards.length) return;

        const searchValue = menuSearch
            ? menuSearch.value.trim().toLowerCase()
            : "";

        let visibleCount = 0;

        menuCards.forEach(function (card) {

            const category = card.dataset.category || "";
            const name = card.dataset.name || "";

            const matchesCategory =
                selectedCategory === "all" ||
                category === selectedCategory;

            const matchesSearch =
                name.toLowerCase().includes(searchValue);

            const visible = matchesCategory && matchesSearch;

            card.hidden = !visible;

            if (visible) visibleCount++;

        });

        if (menuCount) {
            menuCount.textContent =
                visibleCount + (visibleCount === 1
                    ? " menu item found"
                    : " menu items found");
        }

        if (noMenuResults) {
            noMenuResults.hidden = visibleCount !== 0;
        }

    }

    if (menuSearch) {
        menuSearch.addEventListener("input", filterMenu);
    }

    filterButtons.forEach(function (button) {

        button.addEventListener("click", function () {

            filterButtons.forEach(function (item) {
                item.classList.remove("active");
            });

            button.classList.add("active");

            selectedCategory = button.dataset.filter;

            filterMenu();

        });

    });

    if (menuCards.length) {
        filterMenu();
    }

    // =====================================
    // FORM VALIDATION HELPER
    // =====================================

    function validateForm(form) {

        if (!form.checkValidity()) {
            form.reportValidity();
            return false;
        }

        return true;
    }

    // =====================================
    // CUSTOM ORDER ENQUIRY FORM
    // =====================================

    const enquiryForm = document.getElementById("enquiryForm");
    const enquiryError = document.getElementById("enquiryError");
    const enquirySuccess = document.getElementById("enquirySuccess");
    const orderDate = document.getElementById("orderDate");

    if (orderDate) {

        const today = new Date();
        const localDate = new Date(
            today.getTime() - today.getTimezoneOffset() * 60000
        ).toISOString().split("T")[0];

        orderDate.min = localDate;
    }

    if (enquiryForm) {

        enquiryForm.addEventListener("submit", function (event) {

            event.preventDefault();

            if (enquiryError) enquiryError.textContent = "";
            if (enquirySuccess) enquirySuccess.hidden = true;

            if (!validateForm(enquiryForm)) return;

            const formData = new FormData(enquiryForm);

            const name = formData.get("name");
            const email = formData.get("email");
            const phone = formData.get("phone");
            const orderType = formData.get("orderType");
            const date = formData.get("date") || "Not specified";
            const quantity = formData.get("quantity") || "Not specified";
            const details = formData.get("details");
            const budget = formData.get("budget") || "Not specified";

            const summary = [
                "Thank you, " + name + "!",
                "",
                "Your enquiry has passed validation.",
                "",
                "Order type: " + orderType,
                "Email: " + email,
                "Phone: " + phone,
                "Date: " + date,
                "Quantity: " + quantity,
                "Budget: " + budget,
                "",
                "Your requirements:",
                details,
                "",
                "This is a demonstration website. Your enquiry has not been sent or stored."
            ].join("\n");

            if (enquirySuccess) {

                enquirySuccess.textContent = summary;
                enquirySuccess.hidden = false;

                enquirySuccess.scrollIntoView({
                    behavior: "smooth",
                    block: "nearest"
                });

            }

            enquiryForm.reset();

        });

    }

    // =====================================
    // CONTACT FORM
    // =====================================

    const contactForm = document.getElementById("contactForm");
    const contactError = document.getElementById("contactError");

    if (contactForm) {

        contactForm.addEventListener("submit", function (event) {

            event.preventDefault();

            if (contactError) contactError.textContent = "";

            if (!validateForm(contactForm)) return;

            const formData = new FormData(contactForm);

            const name = formData.get("name");
            const email = formData.get("email");
            const phone = formData.get("phone") || "Not supplied";
            const messageType = formData.get("messageType");
            const message = formData.get("message");

            if (bakeryEmail === "hello@example.com") {

                if (contactError) {
                    contactError.textContent =
                        "Please configure the bakery's real email address in js/main.js before using this form.";
                }

                return;
            }

            const subject = encodeURIComponent(
                "Website enquiry: " + messageType
            );

            const body = encodeURIComponent(
                "Name: " + name +
                "\nEmail: " + email +
                "\nPhone: " + phone +
                "\nMessage type: " + messageType +
                "\n\nMessage:\n" + message
            );

            const mailto =
                "mailto:" + bakeryEmail +
                "?subject=" + subject +
                "&body=" + body;

            window.location.href = mailto;

        });

    }

    // =====================================
    // GALLERY LIGHTBOX
    // =====================================

    const galleryItems = Array.from(
        document.querySelectorAll(".gallery-item")
    );

    const lightbox = document.getElementById("lightbox");
    const lightboxImage = document.getElementById("lightboxImage");
    const lightboxCaption = document.getElementById("lightboxCaption");

    const lightboxClose = document.querySelector(".lightbox-close");
    const lightboxPrev = document.querySelector(".lightbox-prev");
    const lightboxNext = document.querySelector(".lightbox-next");

    let currentImage = 0;
    let previousFocus = null;

    function showGalleryImage(index) {

        if (!galleryItems.length || !lightbox) return;

        currentImage =
            (index + galleryItems.length) % galleryItems.length;

        const item = galleryItems[currentImage];
        const image = item.querySelector("img");

        lightboxImage.src = item.dataset.full || image.src;
        lightboxImage.alt = image.alt;

        lightboxCaption.textContent =
            item.dataset.caption || image.alt;

    }

    function openLightbox(index) {

        if (!lightbox) return;

        previousFocus = document.activeElement;

        showGalleryImage(index);

        lightbox.hidden = false;
        document.body.style.overflow = "hidden";

        if (lightboxClose) lightboxClose.focus();

    }

    function closeLightbox() {

        if (!lightbox) return;

        lightbox.hidden = true;
        document.body.style.overflow = "";

        if (previousFocus) previousFocus.focus();

    }

    galleryItems.forEach(function (item, index) {

        item.addEventListener("click", function () {
            openLightbox(index);
        });

    });

    if (lightboxClose) {
        lightboxClose.addEventListener("click", closeLightbox);
    }

    if (lightboxPrev) {
        lightboxPrev.addEventListener("click", function () {
            showGalleryImage(currentImage - 1);
        });
    }

    if (lightboxNext) {
        lightboxNext.addEventListener("click", function () {
            showGalleryImage(currentImage + 1);
        });
    }

    if (lightbox) {

        lightbox.addEventListener("click", function (event) {

            if (event.target === lightbox) {
                closeLightbox();
            }

        });

    }

    document.addEventListener("keydown", function (event) {

        if (!lightbox || lightbox.hidden) return;

        if (event.key === "Escape") {
            closeLightbox();
        }

        if (event.key === "ArrowLeft") {
            showGalleryImage(currentImage - 1);
        }

        if (event.key === "ArrowRight") {
            showGalleryImage(currentImage + 1);
        }

    });

    // =====================================
    // LEAFLET MAP AND ADDRESS SEARCH
    // =====================================

    const mapElement = document.getElementById("map");
    const mapAddress = document.getElementById("mapAddress");
    const mapSearchBtn = document.getElementById("mapSearchBtn");
    const mapMessage = document.getElementById("mapMessage");

    if (mapElement && typeof L !== "undefined") {

        const map = L.map("map").setView(
            [-25.7461, 28.1881],
            5
        );

        L.tileLayer(
            "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            {
                attribution:
                    '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                maxZoom: 19
            }
        ).addTo(map);

        let locationMarker = null;

        if (mapSearchBtn && mapAddress) {

            mapSearchBtn.addEventListener("click", async function () {

                const address = mapAddress.value.trim();

                if (!address) {

                    mapMessage.textContent =
                        "Please enter a complete bakery address.";

                    return;
                }

                mapSearchBtn.disabled = true;
                mapSearchBtn.textContent = "Searching...";

                mapMessage.textContent =
                    "Searching OpenStreetMap for your address...";

                try {

                    const url =
                        "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=" +
                        encodeURIComponent(address);

                    const response = await fetch(url);

                    if (!response.ok) {
                        throw new Error("Location search failed.");
                    }

                    const results = await response.json();

                    if (!results.length) {

                        mapMessage.textContent =
                            "No location found. Check the address and try again.";

                        return;
                    }

                    const result = results[0];

                    const latitude = Number(result.lat);
                    const longitude = Number(result.lon);

                    if (!Number.isFinite(latitude) ||
                        !Number.isFinite(longitude)) {
                        throw new Error("Invalid location coordinates.");
                    }

                    map.setView(
                        [latitude, longitude],
                        16
                    );

                    if (locationMarker) {
                        map.removeLayer(locationMarker);
                    }

                    locationMarker = L.marker([
                        latitude,
                        longitude
                    ]).addTo(map);

                    locationMarker.bindPopup(
                        "Bloom & Co. location search:<br>" +
                        result.display_name
                    ).openPopup();

                    mapMessage.textContent =
                        "Location found. Confirm that this is the correct bakery address.";

                } catch (error) {

                    mapMessage.textContent =
                        "Unable to search right now. Check your internet connection and try again.";

                } finally {

                    mapSearchBtn.disabled = false;
                    mapSearchBtn.textContent = "Find location";

                }

            });

        }

        setTimeout(function () {
            map.invalidateSize();
        }, 300);

    } else if (mapElement && mapMessage) {

        mapMessage.textContent =
            "The map library could not load. Check your internet connection.";

    }

});

// ==========================================
// BLOOM & CO. - CONTACT PAGE
// ==========================================

document.addEventListener("DOMContentLoaded", function () {

    // Update the copyright year
    document.querySelectorAll(".year").forEach(function (element) {
        element.textContent = new Date().getFullYear();
    });

    // --------------------------------------
    // MAP: 135 Celleria, Sunnyside, Pretoria
    // --------------------------------------

    const mapElement = document.getElementById("map");
    const addressInput = document.getElementById("mapAddress");
    const mapSearchButton = document.getElementById("mapSearchBtn");
    const mapMessage = document.getElementById("mapMessage");

    if (mapElement && window.L) {

        const defaultAddress =
            "135 Celleria, 103 Celliers Street, Sunnyside, Pretoria, 0002";

        const map = L.map("map").setView([-25.7545, 28.2040], 15);

        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
            maxZoom: 19
        }).addTo(map);

        let locationMarker = null;

        async function findBakeryLocation(address) {

            if (!address.trim()) {
                mapMessage.textContent = "Please enter an address.";
                return;
            }

            mapMessage.textContent = "Searching for the address...";
            mapSearchButton.disabled = true;

            try {
                const url =
                    "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q=" +
                    encodeURIComponent(address);

                const response = await fetch(url, {
                    headers: {
                        "Accept": "application/json"
                    }
                });

                if (!response.ok) {
                    throw new Error("The map service could not be reached.");
                }

                const results = await response.json();

                if (!results.length) {
                    mapMessage.textContent =
                        "Address not found. Please check the spelling or try a nearby street address.";
                    return;
                }

                const place = results[0];
                const latitude = Number(place.lat);
                const longitude = Number(place.lon);

                if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
                    throw new Error("The map returned an invalid location.");
                }

                if (locationMarker) {
                    map.removeLayer(locationMarker);
                }

                locationMarker = L.marker([latitude, longitude])
                    .addTo(map)
                    .bindPopup(
                        "<strong>Bloom &amp; Co.</strong><br>" +
                        "135 Celleria, Sunnyside, Pretoria"
                    )
                    .openPopup();

                map.setView([latitude, longitude], 17);

                mapMessage.textContent =
                    "Map location found: " + place.display_name;

            } catch (error) {
                mapMessage.textContent =
                    "Unable to load the location right now. Please try again or use the Get directions link.";

                console.error("Map error:", error);

            } finally {
                mapSearchButton.disabled = false;
            }
        }

        mapSearchButton.addEventListener("click", function () {
            findBakeryLocation(addressInput.value);
        });

        addressInput.addEventListener("keydown", function (event) {
            if (event.key === "Enter") {
                event.preventDefault();
                findBakeryLocation(addressInput.value);
            }
        });

        // Search for the supplied address when the page opens.
        findBakeryLocation(defaultAddress);

    } else if (mapElement && !window.L) {
        if (mapMessage) {
            mapMessage.textContent =
                "The map library could not load. Please check your internet connection.";
        }
    }

    // --------------------------------------
    // CONTACT FORM: PREPARE AN EMAIL
    // --------------------------------------

    const contactForm = document.getElementById("contactForm");
    const contactError = document.getElementById("contactError");

    if (contactForm) {

        contactForm.addEventListener("submit", function (event) {
            event.preventDefault();

            if (contactError) {
                contactError.textContent = "";
            }

            if (!contactForm.checkValidity()) {
                contactForm.reportValidity();

                if (contactError) {
                    contactError.textContent =
                        "Please complete all required fields correctly.";
                }

                return;
            }

            const formData = new FormData(contactForm);

            const name = formData.get("name");
            const email = formData.get("email");
            const phone = formData.get("phone") || "Not provided";
            const messageType = formData.get("messageType");
            const message = formData.get("message");

            const recipient = "28nkanyani@gmail.com";

            const subject = encodeURIComponent(
                "Bloom & Co. Website Enquiry - " + messageType
            );

            const body = encodeURIComponent(
                "Name: " + name + "\n" +
                "Email: " + email + "\n" +
                "Phone: " + phone + "\n" +
                "Message type: " + messageType + "\n\n" +
                "Message:\n" + message
            );

            window.location.href =
                "mailto:" + recipient +
                "?subject=" + subject +
                "&body=" + body;
        });
    }

});

// ==========================================
// BLOOM & CO. - GALLERY LIGHTBOX
// ==========================================

document.addEventListener("DOMContentLoaded", function () {

    const galleryItems = Array.from(
        document.querySelectorAll(".gallery-item")
    );

    const lightbox = document.getElementById("lightbox");
    const lightboxImage = document.getElementById("lightboxImage");
    const lightboxCaption = document.getElementById("lightboxCaption");

    const closeButton = document.getElementById("lightboxClose");
    const previousButton = document.getElementById("lightboxPrev");
    const nextButton = document.getElementById("lightboxNext");

    if (!galleryItems.length || !lightbox) {
        return;
    }

    let currentImageIndex = 0;
    let previouslyFocusedElement = null;

    function showImage(index) {

        currentImageIndex =
            (index + galleryItems.length) % galleryItems.length;

        const selectedItem = galleryItems[currentImageIndex];
        const image = selectedItem.querySelector("img");

        const fullImage =
            selectedItem.dataset.full || image.src;

        const caption =
            selectedItem.dataset.caption || image.alt;

        lightboxImage.src = fullImage;
        lightboxImage.alt = image.alt;
        lightboxCaption.textContent =
            caption + " (" + (currentImageIndex + 1) +
            " of " + galleryItems.length + ")";

    }

    function openLightbox(index) {

        previouslyFocusedElement = document.activeElement;

        showImage(index);

        lightbox.classList.add("is-open");
        lightbox.setAttribute("aria-hidden", "false");

        document.body.style.overflow = "hidden";

        closeButton.focus();
    }

    function closeLightbox() {

        lightbox.classList.remove("is-open");
        lightbox.setAttribute("aria-hidden", "true");

        document.body.style.overflow = "";

        lightboxImage.src = "";

        if (previouslyFocusedElement) {
            previouslyFocusedElement.focus();
        }
    }

    galleryItems.forEach(function (item, index) {

        const image = item.querySelector("img");

        // Show an error message if an image cannot load.
        image.addEventListener("error", function () {
            image.alt = "Gallery image could not be loaded.";
            image.style.background = "#e9ded2";
            image.style.objectFit = "contain";

            const message = document.getElementById("galleryMessage");

            if (message) {
                message.textContent =
                    "One or more gallery photographs could not load. Please check your internet connection or image links.";
            }
        });

        item.addEventListener("click", function () {
            openLightbox(index);
        });

    });

    closeButton.addEventListener("click", closeLightbox);

    previousButton.addEventListener("click", function () {
        showImage(currentImageIndex - 1);
    });

    nextButton.addEventListener("click", function () {
        showImage(currentImageIndex + 1);
    });

    lightbox.addEventListener("click", function (event) {
        if (event.target === lightbox) {
            closeLightbox();
        }
    });

    document.addEventListener("keydown", function (event) {

        if (!lightbox.classList.contains("is-open")) {
            return;
        }

        if (event.key === "Escape") {
            closeLightbox();
        }

        if (event.key === "ArrowRight") {
            showImage(currentImageIndex + 1);
        }

        if (event.key === "ArrowLeft") {
            showImage(currentImageIndex - 1);
        }

    });

});
